package database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class RepositorioScripts extends RepositorioGenerico {

	private static final String NOME_BANCO = "respostacerta";
	private static final String SCRIPT_DELETE_TABELA= "DROP TABLE IF EXISTS afirmacao";
	
	private static final String[] SCRIPT_CRIAR_TABELA = new String[] {
		
		"create table afirmacao" +
			"(_id integer primary key autoincrement," +
			"src text not null," +
			"resposta text not null," +
			"nivel integer not null);",
					
		"create table niveis" +
			"(nivel integer primary key," +
			"pt_necessaria integer not null," +
			"pt_atingida integer not null);",
	
		
		
//		"foreign key (nivel) references niveis (nivel));" +
		
		"insert into niveis(nivel, pt_necessaria, pt_atingida) values(1,0,0);",
		"insert into niveis(nivel, pt_necessaria, pt_atingida) values(2,30,0);",
		"insert into niveis(nivel, pt_necessaria, pt_atingida) values(3,80,0);",
		"insert into niveis(nivel, pt_necessaria, pt_atingida) values(4,130,0);",
		"insert into afirmacao(src,resposta,nivel) values('1+1=2', 'T', 1);",
		"insert into afirmacao(src,resposta,nivel) values('1+2=2', 'F', 1);",
		"insert into afirmacao(src,resposta,nivel) values('2+2=4', 'T', 1);",
		"insert into afirmacao(src,resposta,nivel) values('3x2=6', 'T', 1);",
		"insert into afirmacao(src,resposta,nivel) values('1+1=11','F', 1);",
		"insert into afirmacao (src,resposta,nivel) values('2x10=100', 'F', 2);",
		"insert into afirmacao (src,resposta,nivel) values('3x10=300', 'F', 2);",
		"insert into afirmacao (src,resposta,nivel) values('10x0=100', 'F', 2);",
		"insert into afirmacao (src,resposta,nivel) values('2x11=110', 'F', 2);",
		"insert into afirmacao (src,resposta,nivel) values('3x20=32', 'F', 2);"
//		"insert into (src,resposta,nivel) values()" +
//		"insert into (src,resposta,nivel) values()" +
//		"insert into (src,resposta,nivel) values()" +
//		"insert into (src,resposta,nivel) values()" +
//		"insert into (src,resposta,nivel) values()"
//		"insert into () values()" +
//		"insert into () values()" +
//		"insert into () values()" +
//		"insert into () values()" +
//		"insert into () values()" +
//		"insert into () values()" +
//		"insert into () values()" +
//		"insert into () values()" +
//		"insert into () values()" +
//		"insert into () values()" +
		
		
		
		};
	
	private static final int VERSAO_BANCO = 1;

	private SQLiteHelper dbHelper;
	
	public RepositorioScripts(Context ctx) {
		super(ctx);
		dbHelper = new SQLiteHelper(ctx, NOME_BANCO, VERSAO_BANCO, SCRIPT_CRIAR_TABELA, SCRIPT_DELETE_TABELA);
		Log.i("BANCO", "dbHelper de boooa");
		db = dbHelper.getWritableDatabase();
		Log.i("BANCO","getwritable funfou");
		
	}
	@Override
	public void fechar(){
		if(dbHelper != null){
			dbHelper.close();
		}
	}

}

	
	